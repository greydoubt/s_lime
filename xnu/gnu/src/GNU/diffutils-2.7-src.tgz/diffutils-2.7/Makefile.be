# Generated automatically from Makefile.in by configure.
# Makefile for GNU DIFF
# Copyright (C) 1988,1989,1991,1992,1993,1994 Free Software Foundation, Inc.
#
# This file is part of GNU DIFF.
#
# GNU DIFF is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# GNU DIFF is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with GNU DIFF; see the file COPYING.  If not, write to
# the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

#### Start of system configuration section. ####

srcdir = .

CC = bcc
INSTALL = /usr/bin/ginstall -c
INSTALL_PROGRAM = ${INSTALL}
INSTALL_DATA = ${INSTALL} -m 644
MAKEINFO = makeinfo
TEXI2DVI = texi2dvi

CPPFLAGS = 
DEFS = -DHAVE_CONFIG_H
CFLAGS = -O
LDFLAGS = 
BE_LIBS = -nodefaults $(BUILDHOME)/metro/lib/libdll.a \
          $(BUILDHOME)/metro/lib/libpos.so
LIBS = $(BE_LIBS)
LIBOBJS = 

# Some System V machines do not come with libPW.
# If this is true for you, use the GNU alloca.o here.
ALLOCA = 

TOPDIR = $(BUILDHOME)/install
prefix = $(TOPDIR)/system
exec_prefix = $(TOPDIR)
edit_program_name = sed 's,x,x,'

bindir = $(exec_prefix)/bin
destbindir = /bin

infodir = $(prefix)/info

DEFAULT_EDITOR_PROGRAM = ed
DIFF_PROGRAM = $(destbindir)/`echo diff | $(edit_program_name)`
NULL_DEVICE = /dev/null
PR_PROGRAM = /bin/pr

#### End of system configuration section. ####

SHELL = /bin/sh

# The source files for all of the programs.
srcs=diff.c analyze.c cmpbuf.c cmpbuf.h io.c context.c ed.c normal.c ifdef.c \
	util.c dir.c memchr.c waitpid.c \
	version.c diff.h regex.c regex.h side.c system.h \
	diff3.c sdiff.c cmp.c error.c xmalloc.c getopt.c getopt1.c getopt.h \
	fnmatch.c fnmatch.h alloca.c
distfiles = $(srcs) README INSTALL NEWS diagmeet.note Makefile.in \
	stamp-h.in config.hin configure configure.in COPYING ChangeLog \
	diff.texi diff.info* texinfo.tex \
	install-sh mkinstalldirs

PROGRAMS = cmp diff diff3 sdiff

#all: $(PROGRAMS) info
all: $(PROGRAMS)

COMPILE = $(CC) -c $(CPPFLAGS) $(DEFS) -I. -I$(srcdir) $(CFLAGS)

.c.o:
	$(COMPILE) $<

diff_o = diff.o analyze.o cmpbuf.o dir.o io.o util.o \
	context.o ed.o ifdef.o normal.o side.o \
	fnmatch.o regex.o version.o $(ALLOCA) $(LIBOBJS)
diff: $(diff_o)
	$(CC) -o $@ $(CFLAGS) $(LDFLAGS) $(diff_o) $(LIBS)

diff3_o = diff3.o version.o $(LIBOBJS)
diff3: $(diff3_o)
	$(CC) -o $@ $(CFLAGS) $(LDFLAGS) $(diff3_o) $(LIBS)

sdiff_o = sdiff.o version.o $(LIBOBJS)
sdiff: $(sdiff_o)
	$(CC) -o $@ $(CFLAGS) $(LDFLAGS) $(sdiff_o) $(LIBS)

cmp_o = cmp.o cmpbuf.o error.o xmalloc.o version.o $(LIBOBJS)
cmp: $(cmp_o)
	$(CC) -o $@ $(CFLAGS) $(LDFLAGS) $(cmp_o) $(LIBS)

info: diff.info
diff.info: diff.texi
	$(MAKEINFO) $(srcdir)/diff.texi --output=$@

dvi: diff.dvi
diff.dvi: diff.texi
	$(TEXI2DVI) $(srcdir)/diff.texi

$(diff_o): diff.h system.h
cmp.o diff3.o sdiff.o: system.h
context.o diff.o regex.o: regex.h
cmp.o diff.o diff3.o sdiff.o: getopt.h
diff.o fnmatch.o: fnmatch.h
analyze.o cmpbuf.o cmp.o: cmpbuf.h

cmp.o: cmp.c
	$(COMPILE) -DNULL_DEVICE=\"$(NULL_DEVICE)\" $(srcdir)/cmp.c

diff3.o: diff3.c
	$(COMPILE) -DDIFF_PROGRAM=\"$(DIFF_PROGRAM)\" $(srcdir)/diff3.c

sdiff.o: sdiff.c
	$(COMPILE) -DDEFAULT_EDITOR_PROGRAM=\"$(DEFAULT_EDITOR_PROGRAM)\" \
		-DDIFF_PROGRAM=\"$(DIFF_PROGRAM)\" $(srcdir)/sdiff.c

util.o: util.c
	$(COMPILE) -DPR_PROGRAM=\"$(PR_PROGRAM)\" $(srcdir)/util.c

TAGS: $(srcs)
	etags $(srcs)

clean:
	rm -f *.o $(PROGRAMS) core
	rm -f *.aux *.cp *.cps *.dvi *.fn *.fns *.ky *.kys *.log
	rm -f *.pg *.pgs *.toc *.tp *.tps *.vr *.vrs

mostlyclean: clean

distclean: clean
	rm -f Makefile config.cache config.h config.log config.status stamp-h

realclean: distclean
	rm -f TAGS *.info*

install: all installdirs
	for p in $(PROGRAMS); do \
	  $(INSTALL_PROGRAM) $$p $(bindir)/`echo $$p | $(edit_program_name)`; \
	done

#	{ test -f diff.info || cd $(srcdir); } && \
#	for f in diff.info*; do \
#	  $(INSTALL_DATA) $$f $(infodir)/$$f; \
#	done

installdirs:
	$(SHELL) ${srcdir}/mkinstalldirs $(bindir)

#	$(SHELL) ${srcdir}/mkinstalldirs $(bindir) $(infodir)

# We need more tests.
check:
	./cmp cmp cmp
	./diff diff diff
	./diff3 diff3 diff3 diff3
	./sdiff sdiff sdiff

uninstall:
	for p in $(PROGRAMS); do \
	  rm -f $(bindir)/`echo $$p | $(edit_program_name)`; \
	done
	rm -f $(infodir)/diff.info*

configure: configure.in
	cd $(srcdir) && autoconf

# autoheader might not change config.hin.
config.hin: stamp-h.in
stamp-h.in: configure.in
	cd $(srcdir) && autoheader
	date > $(srcdir)/stamp-h.in

config.status: configure
	./config.status --recheck

# config.status might not change config.h, but it changes stamp-h.
config.h: stamp-h
stamp-h: config.hin config.status
	./config.status
Makefile: Makefile.in config.status
	./config.status

dist: $(distfiles)
	echo diffutils-`sed -e '/version_string/!d' -e 's/[^0-9]*\([0-9a-z.]*\).*/\1/' -e q version.c` > .fname
	rm -rf `cat .fname`
	mkdir `cat .fname`
	-ln $(distfiles) `cat .fname`
	for file in $(distfiles); do \
	  [ -r `cat .fname`/$$file ] || cp -p $$file `cat .fname` || exit; \
	done
	tar -chf - `cat .fname` | gzip >`cat .fname`.tar.gz
	rm -rf `cat .fname` .fname

# Prevent GNU make v3 from overflowing arg limit on SysV.
.NOEXPORT:
