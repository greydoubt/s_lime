/\.$/r readin.in2
