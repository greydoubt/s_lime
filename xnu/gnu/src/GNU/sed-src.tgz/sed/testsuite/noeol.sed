s/$/wakuwaku/g
