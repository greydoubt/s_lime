s/foo/bar/g
