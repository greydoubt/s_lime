# Generated automatically from Makefile.in by configure.
# Makefile for GNU Awk support library.
#
# Copyright (C) 1995 the Free Software Foundation, Inc.
# 
# This file is part of GAWK, the GNU implementation of the
# AWK Programming Language.
# 
# GAWK is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# GAWK is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA

SHELL = /bin/sh

srcdir = .

INSTALL = /usr/bin/ginstall -c
INSTALL_PROGRAM = ${INSTALL}
INSTALL_DATA = ${INSTALL} -m 644

CC = bcc
CFLAGS = -O

TOPDIR = $(BUILDHOME)/install
exec_prefix = $(TOPDIR)
prefix = $(TOPDIR)/system
binprefix =
manprefix =

bindir = ${exec_prefix}/bin
libdir = ${prefix}/bin.data
destlibdir = $(TOPDIR)/bin.data
mandir = ${prefix}/man/man1
manext = .1
infodir = ${prefix}/info
datadir = ${prefix}/bin.data/awk
libexecdir = ${prefix}/bin.data/libexec/awk
destlibexecdir = /system/bin.data/libexec/awk

AUXPROGS = pwcat grcat
AUXAWK = passwd.awk group.awk

#all: stamp-eg $(AUXPROGS) igawk $(AUXAWK)
all: $(AUXPROGS) igawk $(AUXAWK)

#stamp-eg: $(srcdir)/../doc/gawk.texi
#	rm -fr eg stamp-eg
#	../gawk -f $(srcdir)/extract.awk $(srcdir)/../doc/gawk.texi
#	@echo 'some makes are stupid and will not check a directory' > stamp-eg
#	@echo 'against a file, so this file is a place holder. gack.' >> stamp-eg

pwcat: $(srcdir)/eg/lib/pwcat.c
	$(CC) $(CFLAGS) $(srcdir)/eg/lib/pwcat.c -o $@

grcat: $(srcdir)/eg/lib/grcat.c
	$(CC) $(CFLAGS) $(srcdir)/eg/lib/grcat.c -o $@

igawk: $(srcdir)/eg/prog/igawk.sh
	cp $(srcdir)/eg/prog/igawk.sh $@ ; chmod 755 $@

passwd.awk: $(srcdir)/eg/lib/passwdawk.in
	(cd $(srcdir)/eg/lib ; \
	sed 's;/usr/local/libexec/awk;$(destlibexecdir);' < passwdawk.in) > passwd.awk

group.awk: $(srcdir)/eg/lib/groupawk.in
	(cd $(srcdir)/eg/lib ; \
	sed 's;/usr/local/libexec/awk;$(destlibexecdir);' < groupawk.in) > group.awk

install: igawk $(AUXPROGS) $(AUXAWK)
	$(INSTALL_PROGRAM) igawk $(bindir)
	for i in $(AUXPROGS) ; do \
		$(INSTALL_PROGRAM) $$i $(libexecdir) ; \
	done
	for i in $(AUXAWK) $(srcdir)/eg/lib/*.awk ; do \
		$(INSTALL_DATA) $$i $(datadir) ; \
	done

# libexecdir and bindir are removed in the top level Makefile's uninstall
uninstall:
	rm -fr $(libexecdir)/* $(datadir)/*
	rm -f $(bindir)/igawk

clean:
	rm -f $(AUXPROGS) igawk

maintainer-clean: clean
	rm -fr eg stamp-eg

distclean: clean
	rm -f Makefile
