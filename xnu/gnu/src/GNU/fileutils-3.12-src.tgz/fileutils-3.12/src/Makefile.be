# Generated automatically from Makefile.in by configure.
# Makefile for GNU file utilities.
# Copyright (C) 1990, 1991, 1992, 1993, 1994 Free Software Foundation, Inc.

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

SHELL = /bin/sh

srcdir = .

TOPDIR = $(BUILDHOME)/install
prefix = $(TOPDIR)/system
exec_prefix = $(TOPDIR)
bindir = $(exec_prefix)/bin
libdir = $(prefix)/bin.data

INSTALL = /usr/bin/ginstall -c
INSTALL_PROGRAM = ${INSTALL}
CC = bcc
DEFS = -DHAVE_CONFIG_H -D_POSIX_VERSION
BE_LIBS = -nodefaults $(BUILDHOME)/metro/lib/libdll.a \
          $(BUILDHOME)/metro/lib/libpos.so
LIBS = $(BE_LIBS)
CFLAGS = -O
LDFLAGS = 
RM = /bin/rm
LN = ln
MV = /bin/mv

SOURCES = chmod.c chgrp.c chown.c cp-aux.c cp-hash.c cp.c \
dd.c df.c du.c install.c ln.c ls.c mkdir.c mkfifo.c mknod.c mv.c mvdir.c \
rm.c rmdir.c sync.c touch.c version.c ls-ls.c ls-dir.c ls-vdir.c

OBJECTS = chmod.o chgrp.o chown.o cp-aux.o cp-hash.o cp.o \
dd.o df.o du.o install.o ln.o ls.o mkdir.o mkfifo.o mknod.o mv.o mvdir.o \
rm.o rmdir.o sync.o touch.o version.o ls-ls.o ls-dir.o ls-vdir.o

DISTFILES = Makefile.in cp.h ls.h version.h $(SOURCES) \
system.h

# Use `ginstall' in the definition of PROGS and in dependencies to avoid
# confusion with the `install' target.  The install rule transforms `ginstall'
# to install before applying any user-specified name transformations.

PROGS = chgrp chown chmod cp dd du ginstall dir vdir ls mkdir \
mv rm rmdir touch

LIBPROGS = 

all: $(PROGS) $(LIBPROGS)

.SUFFIXES:
.SUFFIXES: .c .o

incl = -I.. -I$(srcdir) -I../lib -I$(srcdir)/../lib
.c.o:
	$(CC) -c $(CPPFLAGS) $(DEFS) $(incl) $(CFLAGS) $<

subdir = src
Makefile: ../config.status Makefile.in
	cd .. && CONFIG_FILES=$(subdir)/$@ CONFIG_HEADERS= ./config.status

installdirs:
	$(srcdir)/../mkinstalldirs $(bindir)

transform = s,x,x,
install: all installdirs
	for f in $(PROGS); do \
	  $(INSTALL_PROGRAM) $$f \
	      $(bindir)/`echo $$f|sed 's/ginstall/install/; $(transform)'`; \
	done
	if [ "x$(LIBPROGS)" = x ]; then : ; else \
	  $(INSTALL_PROGRAM) -o root -m 4755 $(LIBPROGS) $(libdir); fi

#	cd $(bindir) && \
#	  $(RM) -f d v && \
#	  $(LN) `echo dir|sed '$(transform)'` d && \
#	  $(LN) `echo vdir|sed '$(transform)'` v

uninstall:
	for f in $(LIBPROGS); do \
	  $(RM) -f $(libdir)/$(LIBPROGS); \
	done
	for f in $(PROGS) d v; do \
	  $(RM) -f \
	      $(bindir)/`echo $$f|sed 's/ginstall/install/; $(transform)'`; \
	done

TAGS: $(SOURCES)
	etags $(SOURCES)

check:

clean:
	$(RM) -f $(PROGS) $(LIBPROGS) *.o core

mostlyclean: clean

distclean: clean
	$(RM) -f Makefile

realclean: distclean
	$(RM) -f TAGS

distdir = ../`cat ../distname`/$(subdir)
dist: $(DISTFILES)
	for file in $(DISTFILES); do \
	  ln $$file $(distdir) \
	    || { echo copying $$file instead; cp -p $$file $(distdir);}; \
	done

# Linking rules.

link_command = $(CC) $(LDFLAGS) -o $@

chmod: chmod.o
	$(link_command) chmod.o ../lib/libfu.a version.o $(LIBS)

chgrp: chgrp.o
	$(link_command) chgrp.o ../lib/libfu.a version.o $(LIBS)

chown: chown.o
	$(link_command) chown.o ../lib/libfu.a version.o $(LIBS)

cp: cp.o cp-hash.o cp-aux.o
	$(link_command) cp.o cp-hash.o cp-aux.o ../lib/libfu.a version.o $(LIBS)

dd: dd.o
	$(link_command) dd.o ../lib/libfu.a version.o $(LIBS)

df: df.o
	$(link_command) df.o ../lib/libfu.a version.o $(LIBS)

dir: ls.o ls-dir.o
	$(link_command) ls.o ls-dir.o ../lib/libfu.a version.o $(LIBS)

du: du.o
	$(link_command) du.o ../lib/libfu.a version.o $(LIBS)

ginstall: install.o
	$(link_command) install.o ../lib/libfu.a version.o $(LIBS)

ln: ln.o
	$(link_command) ln.o ../lib/libfu.a version.o $(LIBS)

ls: ls.o ls-ls.o
	$(link_command) ls.o ls-ls.o ../lib/libfu.a version.o $(LIBS)

mkdir: mkdir.o
	$(link_command) mkdir.o ../lib/libfu.a version.o $(LIBS)

mkfifo: mkfifo.o
	$(link_command) mkfifo.o ../lib/libfu.a version.o $(LIBS)

mknod: mknod.o
	$(link_command) mknod.o ../lib/libfu.a version.o $(LIBS)

mv: mv.o
	$(link_command) mv.o ../lib/libfu.a version.o $(LIBS)

mvdir: mvdir.o
	$(link_command) mvdir.o ../lib/libfu.a version.o $(LIBS)

rm: rm.o
	$(link_command) rm.o ../lib/libfu.a version.o $(LIBS)

rmdir: rmdir.o
	$(link_command) rmdir.o ../lib/libfu.a version.o $(LIBS)

sync: sync.o
	$(link_command) sync.o ../lib/libfu.a version.o $(LIBS)

touch: touch.o
	$(link_command) touch.o ../lib/libfu.a version.o $(LIBS)

vdir: ls.o ls-vdir.o
	$(link_command) ls.o ls-vdir.o ../lib/libfu.a version.o $(LIBS)


$(PROGS) $(LIBPROGS): ../lib/libfu.a version.o
$(OBJECTS): ../lib/pathmax.h

chmod.o: ../lib/modechange.h 
cp-aux.o: cp.h 
cp-hash.o: cp.h 
cp.o: cp.h ../lib/backupfile.h 
df.o: ../lib/mountlist.h ../lib/fsusage.h 
install.o: ../lib/modechange.h 
ln.o: ../lib/backupfile.h 
ls.o: ls.h
mkdir.o: ../lib/modechange.h 
mkfifo.o: ../lib/modechange.h 
mknod.o: ../lib/modechange.h 
mv.o: ../lib/backupfile.h 
install.o mkdir.o: ../lib/makepath.h

# Make all .o files depend on these files even though there are a few
# unnecessary dependencies.
$(OBJECTS): ../config.h system.h version.h

# Tell versions [3.59,3.63) of GNU make not to export all variables.
# Otherwise a system limit (for SysV at least) may be exceeded.
.NOEXPORT:
