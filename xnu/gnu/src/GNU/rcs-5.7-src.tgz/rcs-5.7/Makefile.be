# Generated automatically from Makefile.in by configure.
# Master makefile for RCS

#	$Id: Makefile.in,v 1.6 1995/06/16 06:19:24 eggert Exp $

# Copyright 1995 Paul Eggert
#   Distributed under license by the Free Software Foundation, Inc.
#
# This file is part of RCS.
#
# RCS is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# RCS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with RCS; see the file COPYING.
# If not, write to the Free Software Foundation,
# 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# Report problems and direct all questions to:
#
#    rcs-bugs@cs.purdue.edu

srcdir = .


SHELL = /bin/sh

default :: all

standard_GNU_targets = \
	all install uninstall clean distclean mostlyclean maintainer-clean \
	TAGS info dvi check

maintainer-clean ::
	@echo "This command is intended for maintainers to use;"
	@echo "it deletes files that may require special tools to rebuild."

$(standard_GNU_targets) installcheck installdebug ::
	cd src && $(MAKE) $@

#	cd man && $(MAKE) $@

dist :: $(srcdir)/configure
	cd man && $(MAKE) rcsfile.5
	cd src && $(MAKE) TAGS
	$(MAKE) distclean
	set -x && \
	d=rcs-`sed -n <src/version.c \
		's/.*version_string[^"]*"\([0-9.]*\).*/\1/p' \
	` && \
	rm -fr $$d && \
	mkdir $$d $$d/man $$d/src && \
	ln *.ms ChangeLog configure configure.in COPYING CREDITS \
		INSTALL INSTALL.RCS install-sh \
		Makefile.in mkinstalldirs NEWS README REFS $$d && \
	(cd man && ln *.[0-9] *.[0-9]in \
		ChangeLog COPYING Makefile.in ../$$d/man) && \
	(cd src && ln *.[ch] *.heg *.sh ChangeLog COPYING \
		Makefile.in rcstest TAGS ../$$d/src) && \
	tar -cbf 1 - $$d | gzip -9 >$$d.tar.gz && \
	rm -fr $$d

$(srcdir)/configure : configure.in
	cd $(srcdir) && autoconf

config.status : configure
	./config.status --recheck

#Makefile : Makefile.in config.status
#	./config.status

clean :: clean.
clean. ::
	rm -f confdefs* conftest* core core.* *.core

distclean maintainer-clean :: distclean.
distclean. :: clean.
	rm -f Makefile config.cache config.log config.status
