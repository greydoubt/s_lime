int
send_trans2_req(uchar WordCount, uchar SetupCount, ushort* Setup,
				uchar* params, int param_len,
				uchar* data, int data_len,
				uchar MaxParameterCount, uchar MaxSetupCount,
				uchar MaxDataCount) {
				



	uchar*		buf;
	uchar*		hldr;
	uchar*		common_header;
	nb_header_t	nb_header;
	iovec		vector[10];
	int			total_size;


	ushort		ByteCount;
	




// Generate trans2 info.
	TotalParameterCount = param_len;
	TotalDataCount = data_len;	
	/* xxx  This will change when we want to send large
		requests.  We'll have to do multiple sends.  */


	ByteCount = 3 + TotalParameterCount + TotalDataCount;

	// Now we malloc just enough mem to hold everything BUT
	// the params and data.
	MALLOC(buf, uchar *, (COMMON_HEADER_SIZE + 2*WordCount + 5));
	if (buf == NULL) {
		aprintf("No Memory for %d bytes\n", total_size);
		return B_ERROR;
	}
	hldr = buf;
	put_cifs_header(*vol, hldr);
	*(hldr + command_off) = SMB_COM_TRANSACTION2;
	hldr += wordcount_off;

	uchar_to_ptr(& hldr, WordCount);
	ushort_to_ptr(& hldr, TotalParameterCount);
	ushort_to_ptr(& hldr, TotalDataCount);
	ushort_to_ptr(& hldr, MaxParameterCount);
	ushort_to_ptr(& hldr, MaxDataCount);
	uchar_to_ptr(& hldr, MaxSetupCount);
	uchar_to_ptr(& hldr, 0); // Reserved
	ushort_to_ptr(& hldr, 0);  // Transacton flags - 0 means dont discconect
								// this tid when done.
	ulong_to_ptr(& hldr, Timeout);
	ushort_to_ptr(& hldr, 0); // Reserved2
	ushort_to_ptr(& hldr, ParameterCount);
	ushort_to_ptr(& hldr, ParameterOffset);
	ushort_to_ptr(& hldr, DataCount);
	ushort_to_ptr(& hldr, DataOffset);
	uchar_to_ptr(& hldr, SetupCount);
	uchar_to_ptr(& hldr, 0); // Reserved3
	for(i=0;i<SetupCount;i++) {
		ushort_to_ptr(& hldr, Setup[i]);
	}
	
	ushort_to_ptr(& hldr, ByteCount);
	
	// The following i got by reading the samba source.
	// [i didn't steal anything, i promise.]
	uchar_to_ptr(& hldr, 0); // Just padding.
	uchar_to_ptr(& hldr, 'D');
	uchar_to_ptr(& hldr, ' ');
	
	
	
	nb_header.Command = NB_SESSION_MESSAGE;
	nb_header.Flags = 0;
	put_nb_length(& nb_header, (COMMON_HEADER_SIZE + 2*WordCount + ByteCount + 3));
	vector[0].iov_base = (char *) & nb_header;
	vector[0].iov_len = 4;
	vector[1].iov_base = (char *) buf;
	vector[1].iov_len = COMMON_HEADER_SIZE + 2*WordCount + 5;
	vector[2].iov_base = (char *) params;
	vector[2].iov_len = param_len;
	vector[3].iov_base = (char *) data;
	vector[3].iov_len = data_len;
	
		 
	if (fake_sendv((*vol)->sockid, vector, 4) != B_OK) {
		aprintf("Error in sending.\n");
		FREE(buf);
		FREE(params);
		FREE(data);
		return B_ERROR;
	}








}