# Generated automatically from Makefile.in by configure.
# Makefile for GNU shell utilities.
# Copyright (C) 1991, 1992, 1993, 1994 Free Software Foundation, Inc.

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

SHELL = /bin/sh

srcdir = .

TOPDIR = $(BUILDHOME)/install
prefix=$(TOPDIR)/system
exec_prefix=$(TOPDIR)
bindir = $(exec_prefix)/bin
libdir = $(exec_prefix)/lib

INSTALL = /usr/bin/ginstall -c
INSTALL_PROGRAM = ${INSTALL}
CC = bcc
DEFS = -DHAVE_CONFIG_H
BE_LIBS = -nodefaults $(BUILDHOME)/metro/lib/libdll.a \
          $(BUILDHOME)/metro/lib/libpos.so
LIBS = $(BE_LIBS)
CFLAGS = -O
LDFLAGS = 
RM = rm

SOURCES = basename.c date.c dirname.c echo.c env.c expr.c hostname.c id.c \
logname.c pathchk.c printenv.c printf.c pwd.c sleep.c su.c \
tee.c test.c tty.c who.c whoami.c yes.c nice.c stty.c uname.c version.c

OBJECTS = basename.o date.o dirname.o echo.o env.o expr.o hostname.o id.o \
logname.o pathchk.o printenv.o printf.o pwd.o sleep.o su.o \
tee.o test.o tty.o users.o who.o whoami.o yes.o nice.o stty.o uname.o \
version.o

DISTFILES = Makefile.in system.h $(SOURCES) groups.sh nohup.sh \
false.sh true.sh version.h

PROGS = basename dirname echo env expr false groups id logname \
pathchk printenv printf pwd sleep tee test true tty yes uname stty

LIBPROGS =

# all: $(PROGS) su $(LIBPROGS)
all: $(PROGS) $(LIBPROGS)

.SUFFIXES:
.SUFFIXES: .c .o

incl = -I.. -I$(srcdir) -I../lib -I$(srcdir)/../lib
.c.o:
	$(CC) -c $(CPPFLAGS) $(DEFS) $(incl) $(CFLAGS) $<

subdir = src
Makefile: ../config.status Makefile.in
	cd .. && CONFIG_FILES=$(subdir)/$@ CONFIG_HEADERS= ./config.status

installdirs:
	$(srcdir)/../mkinstalldirs $(bindir)

transform = s,x,x,
install: all installdirs
	for f in $(PROGS); do \
	  $(INSTALL_PROGRAM) $$f \
	      $(bindir)/`echo $$f|sed '$(transform)'`; \
	done
	$(RM) -f $(bindir)/'['; cp $(bindir)/$(binprefix)test $(bindir)/'['

#	$(RM) -f $(bindir)/'['; ln $(bindir)/$(binprefix)test $(bindir)/'['
	@if test `./id -u` = 0; then \
	echo you are root, so installing su; \
	$(INSTALL_PROGRAM) su $(bindir)/$(binprefix)su; \
	chown root $(bindir)/$(binprefix)su; \
	chmod 4755 $(bindir)/$(binprefix)su; \
	else echo WARNING: you are not root, so not installing su; fi

uninstall:
	$(RM) -f $(bindir)/'['
	for f in $(PROGS) su; do \
	  $(RM) -f \
	      $(bindir)/`echo $$f|sed '$(transform)'`; \
	done

TAGS: $(SOURCES)
	etags $(SOURCES)

check:

clean:
	$(RM) -f $(PROGS) su $(LIBPROGS) *.o core '[' .version users.c

mostlyclean: clean

distclean: clean
	$(RM) -f Makefile

realclean: distclean
	$(RM) -f TAGS

distdir = ../`cat ../distname`/$(subdir)
dist: $(DISTFILES)
	for file in $(DISTFILES); do \
	  ln $$file $(distdir) \
	    || { echo copying $$file instead; cp -p $$file $(distdir);}; \
	done

# Linking rules.

link_command = $(CC) $(LDFLAGS) -o $@

.version: version.c
	sed -e '/version_string/!d' \
	    -e 's/[^"]*"\([^"]*\)".*/\1/' \
	    -e q $(srcdir)/version.c \
	  > $@-t
	mv $@-t $@

basename: basename.o
	$(link_command) basename.o ../lib/libshu.a version.o $(LIBS)

date: date.o
	$(link_command) date.o ../lib/libshu.a version.o $(LIBS)

dirname: dirname.o
	$(link_command) dirname.o ../lib/libshu.a version.o $(LIBS)

echo: echo.o
	$(link_command) echo.o ../lib/libshu.a version.o $(LIBS)

env: env.o
	$(link_command) env.o ../lib/libshu.a version.o $(LIBS)

expr: expr.o
	$(link_command) expr.o ../lib/libshu.a version.o $(LIBS)

false: false.sh .version
	$(RM) -f $@ $@-t
	sed -e "s/@VERSION@/`cat .version`/" $(srcdir)/false.sh \
	    > $@-t
	mv $@-t $@
	chmod +x $@

groups: groups.sh .version
	$(RM) -f $@ $@-t
	sed -e "s,@bindir@,$(bindir),g" \
	    -e "s/@VERSION@/`cat .version`/" $(srcdir)/groups.sh \
	    > $@-t
	mv $@-t $@
	chmod +x $@

hostname: hostname.o 
	$(link_command) hostname.o ../lib/libshu.a version.o $(LIBS)

id: id.o
	$(link_command) id.o ../lib/libshu.a version.o $(LIBS)

logname: logname.o
	$(link_command) logname.o ../lib/libshu.a version.o $(LIBS)

nohup: nohup.sh .version
	$(RM) -f $@ $@-t
	sed -e "s,@bindir@,$(bindir),g" \
	    -e "s/@VERSION@/`cat .version`/" $(srcdir)/nohup.sh \
	    > $@-t
	mv $@-t $@
	chmod +x $@

pathchk: pathchk.o
	$(link_command) pathchk.o ../lib/libshu.a version.o $(LIBS)

printenv: printenv.o
	$(link_command) printenv.o ../lib/libshu.a version.o $(LIBS)

# Link with -lm in case strtod.o needs to get `pow'.
printf: printf.o
	$(link_command) printf.o ../lib/libshu.a version.o $(LIBS)

#	$(link_command) printf.o ../lib/libshu.a version.o $(LIBS) -lm

pwd: pwd.o 
	$(link_command) pwd.o ../lib/libshu.a version.o $(LIBS)

sleep: sleep.o
	$(link_command) sleep.o ../lib/libshu.a version.o $(LIBS)

su: su.o
	$(link_command) su.o ../lib/libshu.a version.o $(LIBS)

tee: tee.o
	$(link_command) tee.o ../lib/libshu.a version.o $(LIBS)

test: test.o
	$(link_command) test.o ../lib/libshu.a version.o $(LIBS)

true: true.sh .version
	$(RM) -f $@ $@-t
	sed -e "s/@VERSION@/`cat .version`/" $(srcdir)/true.sh \
	    > $@-t
	mv $@-t $@
	chmod +x $@

tty: tty.o
	$(link_command) tty.o ../lib/libshu.a version.o $(LIBS)

users: users.o
	$(link_command) users.o ../lib/libshu.a version.o $(LIBS)

who: who.o
	$(link_command) who.o ../lib/libshu.a version.o $(LIBS)

whoami: whoami.o
	$(link_command) whoami.o ../lib/libshu.a version.o $(LIBS)

yes: yes.o
	$(link_command) yes.o ../lib/libshu.a version.o $(LIBS)

nice: nice.o
	$(link_command) nice.o ../lib/libshu.a version.o $(LIBS)

stty: stty.o
	$(link_command) stty.o ../lib/libshu.a version.o $(LIBS)

uname: uname.o
	$(link_command) uname.o ../lib/libshu.a version.o $(LIBS)

# Special rules for some .o files.

su.o: su.c
	$(CC) -c $(CPPFLAGS) -DSYSLOG_FAILURE -DSYSLOG_SUCCESS $(DEFS) \
	    $(incl) $(CFLAGS) $(srcdir)/su.c

test.o: test.c
	$(CC) -c $(CPPFLAGS) -DTEST_STANDALONE $(DEFS) \
	    $(incl) $(CFLAGS) $(srcdir)/test.c

users.o: users.c
	$(CC) -c $(CPPFLAGS) -DUSERS $(DEFS) $(incl) $(CFLAGS) $<
users.c: who.c
	$(RM) -f users.c
	ln $(srcdir)/who.c users.c >/dev/null 2>&1 \
	    || cp $(srcdir)/who.c users.c

who.o: who.c
	$(CC) -c $(CPPFLAGS) -DWHO $(DEFS) $(incl) $(CFLAGS) $<

$(PROGS) su $(LIBPROGS): ../lib/libshu.a version.o
env.o id.o nice.o pathchk.o stty.o su.o tty.o uname.o users.o who.o: \
  ../lib/getopt.h
expr.o: ../lib/regex.h
basename.o dirname.o echo.o expr.o hostname.o nice.o printf.o pwd.o \
  stty.o test.o yes.o: ../lib/long-options.h

# Make all .o files depend on these files even though there are a few
# unnecessary dependencies.
$(OBJECTS): ../config.h system.h version.h

# Tell versions [3.59,3.63) of GNU make not to export all variables.
# Otherwise a system limit (for SysV at least) may be exceeded.
.NOEXPORT:
