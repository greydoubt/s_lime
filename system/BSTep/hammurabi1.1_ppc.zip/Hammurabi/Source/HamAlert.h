//Hammurabi
//Matt Wronkiewicz, 1997 10 12


#pragma once


#ifndef HamAlert_h
#define HamAlert_h


class HamAlert : public BWindow
	{
	public:
		HamAlert(const char* message, const char* image_name, bool new_is_end);
		virtual bool QuitRequested();
	protected:
		bool is_end;
	};


#endif