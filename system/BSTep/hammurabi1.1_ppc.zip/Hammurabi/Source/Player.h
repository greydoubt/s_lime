//Hammurabi
//Matt Wronkiewicz, 1997 10 12


#pragma once


#ifndef Player_h
#define Player_h


class HamConsole;


class Player
	{
	public:
		Player (HamConsole* new_console);
		void doStats ();
		void doBuy ();
		void doSell ();
		void doGrow ();
		void doFeed ();
		void doPlant ();
		void doRats ();
		void updateControls ();
		void doEnd ();
		bool isRebellion ();
	protected:
		int land;
		int population;
		int storage;
		int last_yield;
		int last_food;
		int harvest;
		int land_price;
		int flooded;
		int rats;
		int rat_grain;
		bool plague;
		HamConsole* console;
	};


#endif