//Hammurabi
//Matt Wronkiewicz, 1997 10 12


#pragma once


#ifndef HamConsole_h
#define HamConsole_h


class Player;


class HamConsole : public BWindow
	{
	public:
		HamConsole();
		virtual bool QuitRequested();
		virtual void MessageReceived(BMessage* msg);
		void setYear(int year);
		void setPopulation(int population);
		void setStorage(int storage);
		void setLand(int land);
		void setMarket(int land_price);
		int getFeed();
		void setFeed(int feed);
		int getPlant();
		void setPlant(int land);
		int getTrade();
		void setTrade(int land);
		BStatusBar* feed_status;
		BStatusBar* plant_status;
	protected:
		BStringView* year_control;
		BStringView* population_control;
		BStringView* land_control;
		BStringView* storage_control;
		BStringView* market_control;
		BTextControl* trade_control;
		BTextControl* feed_control;
		BTextControl* plant_control;
		int year;
		int end_year;
		Player* player;
	};


#endif