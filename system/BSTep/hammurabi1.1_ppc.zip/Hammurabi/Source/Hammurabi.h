//Hammurabi
//Matt Wronkiewicz, 1997 10 12


#pragma once


#ifndef Hammurabi_h
#define Hammurabi_h


class Hammurabi : public BApplication
	{
	public:
		Hammurabi ();
		status_t GetResource(const char* name, BMessage* msg);
	protected:
		BResources* rsrcs;
	};


#endif