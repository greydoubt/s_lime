//Hammurabi
//Matt Wronkiewicz, 1997 10 12


#include "Hammurabi.h"


int main (void)
	{
	Hammurabi* game = new Hammurabi();
	
	srand(time(NULL));
	
	game->Run();
	
	delete game;
	return 0;
	}